#define numLed 6
int ledPins[numLed] = {8, 9, 10, 11, 12, 13};

void setup() {
  for (int i = 0; i < numLed; i++) {  // use < not <=
    pinMode(ledPins[i], OUTPUT);
  }
}

void loop() {
  for (int i = 0; i < numLed; i++) {  // use < not <=
    if (i % 2 == 0) {
      digitalWrite(ledPins[i], HIGH);
    } else {
      digitalWrite(ledPins[i], LOW);
    }
  }
  
  delay(500);
  
  for (int i = 0; i < numLed; i++) {  // use < not <=
    if (i % 2 == 1) {
      digitalWrite(ledPins[i], HIGH); // also fixed logic: ON for odd pins
    } else {
      digitalWrite(ledPins[i], LOW);  // OFF for even pins
    }
  }
  
  delay(500);
}
